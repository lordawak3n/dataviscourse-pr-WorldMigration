Hello!

To use this parser please run command prompt and change the present working directory to the where the executible "WorldImmigrationDataParser.exe" 
is extracted/unzipped.

Now run the executible with two arguments <input .csv file name with path> <Output Directory>

For eg.
>> WorldImmigrationDataParser.exe D:\DataVizProject\input.csv D:\DataVizProject\OutputFolder

NOTE: Please use the input.csv file present in the ExampleOutput folder. Otherwise in order to use the original .csv file please change the country name
of "Hong Kong, China" to "Hong Kong **<some other character>** China".

For any questions please contact me on my email @rhul840@gmail.com 

===================================================================

Thank you!